package org.osanchezhuerta.eventscheduling.engine.soa.persistence;

public class T {

}
