package org.osanchezhuerta.eventscheduling.engine.soa.services.consumer.impl;

import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageListener;

public class EngineIdentityReplyListener  implements MessageListener {

	@Override
	public void onMessage(Message message) {

		
		
	}

}

